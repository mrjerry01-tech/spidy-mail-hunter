/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        dusk: {
          950: "#0D1117",
          900: "#131A24",
          800: "#1B2431",
          700: "#25313F",
          600: "#37475A",
          400: "#7E8CA0",
          200: "#C9D1DC",
          100: "#EDF1F6",
        },
        thread: {
          DEFAULT: "#E8A63A",
          bright: "#FFC966",
          dim: "#B27C24",
        },
        catch: "#3FB88A",
        empty: "#D6B23E",
        broken: "#E2664F",
        hunt: "#5C8CE0",
      },
      fontFamily: {
        display: ["'Space Grotesk'", "sans-serif"],
        body: ["'Inter'", "sans-serif"],
        mono: ["'IBM Plex Mono'", "monospace"],
      },
    },
  },
  plugins: [],
};
