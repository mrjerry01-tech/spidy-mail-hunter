export type ScanStatus = "queued" | "processing" | "email_found" | "no_email_found" | "broken_link";

export type EmailSource =
  | "visible_text"
  | "mailto"
  | "html"
  | "button"
  | "rendered_dom"
  | "obfuscated_text"
  | "embedded_data";

export interface FoundEmail {
  email: string;
  source: EmailSource;
}

export interface ScanResult {
  inputIndex: number;
  url: string;
  normalizedUrl: string | null;
  status: ScanStatus;
  emails: FoundEmail[];
  httpStatus: number | null;
  error: string | null;
  usedBrowserRender: boolean;
  startedAt: number | null;
  finishedAt: number | null;
}

export interface BatchProgress {
  total: number;
  completed: number;
  emailFound: number;
  noEmailFound: number;
  brokenLink: number;
}

export type SseEvent =
  | { type: "progress"; progress: BatchProgress }
  | { type: "result"; result: ScanResult }
  | { type: "done"; progress: BatchProgress }
  | { type: "error"; message: string };

export type ResultFilter = "all" | "email_found" | "no_email_found" | "broken_link";
