import { useCallback, useRef, useState } from "react";
import { UrlInput } from "./components/UrlInput";
import { ProgressPanel } from "./components/ProgressPanel";
import { ResultsTable } from "./components/ResultsTable";
import { ExportBar } from "./components/ExportBar";
import { parseUrlsFromText } from "./lib/parseUrls";
import { startHunt, cancelHunt } from "./lib/api";
import type { BatchProgress, ResultFilter, ScanResult } from "./types";

type RunState = "idle" | "running" | "paused" | "finished";

const EMPTY_PROGRESS: BatchProgress = { total: 0, completed: 0, emailFound: 0, noEmailFound: 0, brokenLink: 0 };

export default function App() {
  const [inputText, setInputText] = useState("");
  const [submittedUrls, setSubmittedUrls] = useState<string[]>([]);
  const [results, setResults] = useState<ScanResult[]>([]);
  const [progress, setProgress] = useState<BatchProgress>(EMPTY_PROGRESS);
  const [runState, setRunState] = useState<RunState>("idle");
  const [filter, setFilter] = useState<ResultFilter>("all");
  const [search, setSearch] = useState("");

  const huntRef = useRef<ReturnType<typeof startHunt> | null>(null);
  const completedIndicesRef = useRef<Set<number>>(new Set());

  const beginHunt = useCallback((urls: string[], startIndexOffset: number, existingResults: ScanResult[]) => {
    setRunState("running");
    huntRef.current = startHunt(urls, {
      onResult: (result) => {
        const absoluteIndex = result.inputIndex + startIndexOffset;
        completedIndicesRef.current.add(absoluteIndex);
        setResults((prev) => {
          const next = [...prev];
          next[absoluteIndex] = { ...result, inputIndex: absoluteIndex };
          return next;
        });
      },
      onProgress: (p) => {
        setProgress((prev) => ({
          total: existingResults.length + p.total,
          completed: existingResults.filter((r) => r).length + p.completed,
          emailFound: existingResults.filter((r) => r?.status === "email_found").length + p.emailFound,
          noEmailFound: existingResults.filter((r) => r?.status === "no_email_found").length + p.noEmailFound,
          brokenLink: existingResults.filter((r) => r?.status === "broken_link").length + p.brokenLink,
        }));
      },
      onDone: () => {
        setRunState("finished");
      },
      onError: () => {
        setRunState("finished");
      },
    });
  }, []);

  const handleStart = useCallback(() => {
    const urls = parseUrlsFromText(inputText);
    if (urls.length === 0) return;

    setSubmittedUrls(urls);
    const placeholders: ScanResult[] = urls.map((url, inputIndex) => ({
      inputIndex,
      url,
      normalizedUrl: null,
      status: "processing",
      emails: [],
      httpStatus: null,
      error: null,
      usedBrowserRender: false,
      startedAt: null,
      finishedAt: null,
    }));
    setResults(placeholders);
    setProgress({ total: urls.length, completed: 0, emailFound: 0, noEmailFound: 0, brokenLink: 0 });
    completedIndicesRef.current = new Set();
    setFilter("all");
    setSearch("");
    beginHunt(urls, 0, []);
  }, [inputText, beginHunt]);

  const handleClear = useCallback(() => {
    setInputText("");
    setSubmittedUrls([]);
    setResults([]);
    setProgress(EMPTY_PROGRESS);
    setRunState("idle");
    setFilter("all");
    setSearch("");
  }, []);

  const handlePause = useCallback(() => {
    huntRef.current?.abort();
    setRunState("paused");
  }, []);

  const handleResume = useCallback(() => {
    // Re-submit only the URLs that have not yet produced a final result,
    // preserving their original absolute inputIndex via the offset trick below.
    const pendingEntries = submittedUrls
      .map((url, index) => ({ url, index }))
      .filter(({ index }) => !results[index] || results[index].status === "processing");

    if (pendingEntries.length === 0) {
      setRunState("finished");
      return;
    }

    // Build a temporary mapping: the resumed batch's local inputIndex -> absolute index.
    const indexMap = pendingEntries.map((e) => e.index);
    setRunState("running");
    huntRef.current = startHunt(
      pendingEntries.map((e) => e.url),
      {
        onResult: (result) => {
          const absoluteIndex = indexMap[result.inputIndex];
          setResults((prev) => {
            const next = [...prev];
            next[absoluteIndex] = { ...result, inputIndex: absoluteIndex };
            return next;
          });
        },
        onProgress: () => {
          setResults((current) => {
            const completed = current.filter((r) => r && r.status !== "processing").length;
            setProgress({
              total: submittedUrls.length,
              completed,
              emailFound: current.filter((r) => r?.status === "email_found").length,
              noEmailFound: current.filter((r) => r?.status === "no_email_found").length,
              brokenLink: current.filter((r) => r?.status === "broken_link").length,
            });
            return current;
          });
        },
        onDone: () => setRunState("finished"),
        onError: () => setRunState("finished"),
      }
    );
  }, [submittedUrls, results]);

  const handleStop = useCallback(async () => {
    const batchId = huntRef.current?.getBatchId();
    huntRef.current?.abort();
    if (batchId) await cancelHunt(batchId);
    setRunState("finished");
  }, []);

  const isBusy = runState === "running";

  return (
    <div className="min-h-screen bg-dusk-950">
      <header className="border-b border-dusk-800 px-6 py-8 sm:px-10">
        <div className="mx-auto max-w-5xl">
          <div className="flex items-center gap-3">
            <span className="font-display text-2xl text-thread" aria-hidden>
              ◈
            </span>
            <h1 className="font-display text-2xl font-semibold tracking-tight text-dusk-100 sm:text-3xl">
              Spidy Mail Hunter
            </h1>
          </div>
          <p className="mt-1.5 max-w-lg text-sm text-dusk-400">
            Hunt publicly available emails from any webpage — one URL or a thousand, in the order you gave them.
          </p>
        </div>
      </header>

      <main className="mx-auto max-w-5xl space-y-5 px-6 py-8 sm:px-10">
        <UrlInput value={inputText} onChange={setInputText} onStart={handleStart} onClear={handleClear} disabled={isBusy} />

        {(runState !== "idle" || results.length > 0) && (
          <ProgressPanel
            progress={progress}
            isRunning={runState === "running" || runState === "paused"}
            isPaused={runState === "paused"}
            onPause={handlePause}
            onResume={handleResume}
            onStop={handleStop}
          />
        )}

        {results.length > 0 && (
          <>
            <ExportBar results={results.filter(Boolean)} />
            <ResultsTable
              results={results.filter(Boolean)}
              filter={filter}
              onFilterChange={setFilter}
              search={search}
              onSearchChange={setSearch}
            />
          </>
        )}
      </main>

      <footer className="mx-auto max-w-5xl px-6 py-8 text-xs text-dusk-600 sm:px-10">
        Only inspects publicly accessible page content. Does not bypass logins, paywalls, CAPTCHAs, or access controls.
      </footer>
    </div>
  );
}
