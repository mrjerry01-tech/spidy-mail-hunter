import { describe, expect, it } from "vitest";
import { parseUrlsFromText, looksLikeUrl } from "../parseUrls";

describe("parseUrlsFromText", () => {
  it("splits on newlines", () => {
    expect(parseUrlsFromText("a.com\nb.com\nc.com")).toEqual(["a.com", "b.com", "c.com"]);
  });

  it("splits on commas and spaces, mixed", () => {
    expect(parseUrlsFromText("a.com, b.com c.com,d.com")).toEqual(["a.com", "b.com", "c.com", "d.com"]);
  });

  it("preserves order and duplicates", () => {
    expect(parseUrlsFromText("a.com\nb.com\na.com")).toEqual(["a.com", "b.com", "a.com"]);
  });

  it("ignores blank lines", () => {
    expect(parseUrlsFromText("a.com\n\n\nb.com")).toEqual(["a.com", "b.com"]);
  });
});

describe("looksLikeUrl", () => {
  it("accepts bare domains", () => {
    expect(looksLikeUrl("example.com")).toBe(true);
  });
  it("accepts full URLs", () => {
    expect(looksLikeUrl("https://example.com/contact")).toBe(true);
  });
  it("rejects plain words", () => {
    expect(looksLikeUrl("hello")).toBe(false);
  });
});
