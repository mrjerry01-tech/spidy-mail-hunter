import type { ScanResult, SseEvent, BatchProgress } from "../types";

const API_BASE = import.meta.env.VITE_API_BASE_URL || "";

export interface HuntCallbacks {
  onResult: (result: ScanResult) => void;
  onProgress: (progress: BatchProgress) => void;
  onDone: (progress: BatchProgress) => void;
  onError: (message: string) => void;
}

/**
 * Streams /api/hunt results via SSE. Returns a controller with `abort()` so
 * the UI's Stop button can cancel the in-flight fetch immediately, and the
 * batchId (once known) so a server-side cancel can also be issued.
 */
export function startHunt(urls: string[], callbacks: HuntCallbacks) {
  const controller = new AbortController();
  let batchId: string | null = null;

  (async () => {
    try {
      const res = await fetch(`${API_BASE}/api/hunt`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ urls }),
        signal: controller.signal,
      });

      batchId = res.headers.get("X-Batch-Id");

      if (!res.ok || !res.body) {
        const payload = await res.json().catch(() => ({ error: "Request failed" }));
        callbacks.onError(payload.error || "Request failed");
        return;
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        const events = buffer.split("\n\n");
        buffer = events.pop() || "";

        for (const chunk of events) {
          const line = chunk.split("\n").find((l) => l.startsWith("data: "));
          if (!line) continue;
          const event = JSON.parse(line.slice("data: ".length)) as SseEvent;
          if (event.type === "result") callbacks.onResult(event.result);
          else if (event.type === "progress") callbacks.onProgress(event.progress);
          else if (event.type === "done") callbacks.onDone(event.progress);
          else if (event.type === "error") callbacks.onError(event.message);
        }
      }
    } catch (err: any) {
      if (err?.name !== "AbortError") {
        callbacks.onError(err?.message || "Connection lost");
      }
    }
  })();

  return {
    abort: () => controller.abort(),
    getBatchId: () => batchId,
  };
}

export async function cancelHunt(batchId: string) {
  await fetch(`${API_BASE}/api/hunt/${batchId}/cancel`, { method: "POST" }).catch(() => {});
}
