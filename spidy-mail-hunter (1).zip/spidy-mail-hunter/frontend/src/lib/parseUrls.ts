/**
 * Parses free-form pasted text into an ordered list of URLs. Users may
 * separate entries with newlines, spaces, or commas (or a mix of all three).
 * Order of first appearance is always preserved; duplicates are KEPT
 * (the backend/results table is responsible for showing each occurrence).
 */
export function parseUrlsFromText(raw: string): string[] {
  return raw
    .split(/[\n\r,]+|\s+/)
    .map((token) => token.trim())
    .filter(Boolean);
}

const LOOSE_URL_PATTERN = /^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(\/.*)?$|^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//;

export function looksLikeUrl(token: string): boolean {
  return LOOSE_URL_PATTERN.test(token);
}

export function countValidUrls(raw: string): number {
  return parseUrlsFromText(raw).filter(looksLikeUrl).length;
}
