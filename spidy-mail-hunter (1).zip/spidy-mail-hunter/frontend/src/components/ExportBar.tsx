import type { ScanResult } from "../types";

interface Props {
  results: ScanResult[];
}

function statusLabel(status: ScanResult["status"]): string {
  switch (status) {
    case "email_found":
      return "Email Found";
    case "no_email_found":
      return "No Email Found";
    case "broken_link":
      return "Link is Broken";
    default:
      return "Processing";
  }
}

function download(filename: string, content: string, mime: string) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function toCsv(results: ScanResult[]): string {
  const rows = ["Index,URL,Status,Email"];
  for (const r of results) {
    const index = r.inputIndex + 1;
    const url = csvEscape(r.url);
    const status = statusLabel(r.status);
    if (r.emails.length === 0) {
      rows.push(`${index},${url},${status},`);
    } else {
      for (const e of r.emails) rows.push(`${index},${url},${status},${csvEscape(e.email)}`);
    }
  }
  return rows.join("\n");
}

function csvEscape(value: string): string {
  if (/[",\n]/.test(value)) return `"${value.replace(/"/g, '""')}"`;
  return value;
}

function toTxt(results: ScanResult[]): string {
  return results
    .map((r) => {
      const header = `${r.inputIndex + 1}. ${r.url} — ${statusLabel(r.status)}`;
      const emails = r.emails.length ? r.emails.map((e) => `   ${e.email}`).join("\n") : "";
      return emails ? `${header}\n${emails}` : header;
    })
    .join("\n\n");
}

function uniqueEmails(results: ScanResult[]): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const r of results) {
    for (const e of r.emails) {
      const key = e.email.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(e.email);
    }
  }
  return out;
}

async function copyText(text: string) {
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    /* ignore */
  }
}

export function ExportBar({ results }: Props) {
  const disabled = results.length === 0;
  const buttonClass =
    "rounded-sm border border-dusk-600 px-3 py-1.5 font-mono text-xs text-dusk-200 transition hover:border-thread hover:text-thread disabled:cursor-not-allowed disabled:opacity-40";

  return (
    <div className="flex flex-wrap gap-2">
      <button disabled={disabled} className={buttonClass} onClick={() => copyText(uniqueEmails(results).join("\n"))}>
        Copy All Emails
      </button>
      <button disabled={disabled} className={buttonClass} onClick={() => copyText(toTxt(results))}>
        Copy Results
      </button>
      <button disabled={disabled} className={buttonClass} onClick={() => download("spidy-mail-hunter-results.csv", toCsv(results), "text/csv")}>
        Export CSV
      </button>
      <button
        disabled={disabled}
        className={buttonClass}
        onClick={() => download("spidy-mail-hunter-results.json", JSON.stringify(results, null, 2), "application/json")}
      >
        Export JSON
      </button>
      <button disabled={disabled} className={buttonClass} onClick={() => download("spidy-mail-hunter-results.txt", toTxt(results), "text/plain")}>
        Export TXT
      </button>
    </div>
  );
}
