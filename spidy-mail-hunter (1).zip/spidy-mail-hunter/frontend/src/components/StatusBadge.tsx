import type { ScanStatus } from "../types";

const CONFIG: Record<ScanStatus, { label: string; icon: string; className: string }> = {
  queued: { label: "Queued", icon: "…", className: "text-dusk-400 border-dusk-600" },
  processing: { label: "Hunting…", icon: "●", className: "text-hunt border-hunt/40 bg-hunt/10" },
  email_found: { label: "Email Found", icon: "✓", className: "text-catch border-catch/40 bg-catch/10" },
  no_email_found: { label: "No Email Found", icon: "○", className: "text-empty border-empty/40 bg-empty/10" },
  broken_link: { label: "Link is Broken", icon: "×", className: "text-broken border-broken/40 bg-broken/10" },
};

export function StatusBadge({ status }: { status: ScanStatus }) {
  const c = CONFIG[status];
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 font-mono text-xs ${c.className}`}>
      <span aria-hidden>{c.icon}</span>
      {c.label}
    </span>
  );
}
