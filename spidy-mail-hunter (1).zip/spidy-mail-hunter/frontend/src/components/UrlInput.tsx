import { useMemo } from "react";
import { countValidUrls, parseUrlsFromText } from "../lib/parseUrls";

interface Props {
  value: string;
  onChange: (value: string) => void;
  onStart: () => void;
  onClear: () => void;
  disabled: boolean;
}

export function UrlInput({ value, onChange, onStart, onClear, disabled }: Props) {
  const total = useMemo(() => parseUrlsFromText(value).length, [value]);
  const valid = useMemo(() => countValidUrls(value), [value]);

  return (
    <div className="border border-dusk-700 bg-dusk-900 rounded-sm">
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-dusk-700">
        <span className="font-mono text-xs uppercase tracking-wide text-dusk-400">Paste source URLs</span>
        <span className="font-mono text-xs text-dusk-400">
          {valid} valid <span className="text-dusk-600">/</span> {total} entered
        </span>
      </div>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        disabled={disabled}
        rows={8}
        spellCheck={false}
        placeholder={"https://example.com\nhttps://example.org/contact\nhttps://example.net/about\n\nSeparate with new lines, spaces, or commas."}
        className="w-full resize-y bg-transparent px-4 py-3 font-mono text-sm text-dusk-100 placeholder:text-dusk-600 outline-none disabled:opacity-50"
      />
      <div className="flex flex-wrap items-center gap-3 px-4 py-3 border-t border-dusk-700">
        <button
          onClick={onStart}
          disabled={disabled || valid === 0}
          className="inline-flex items-center gap-2 rounded-sm bg-thread px-4 py-2 text-sm font-semibold text-dusk-950 transition hover:bg-thread-bright disabled:cursor-not-allowed disabled:bg-dusk-700 disabled:text-dusk-400"
        >
          Start Hunting
        </button>
        <button
          onClick={onClear}
          disabled={disabled}
          className="rounded-sm border border-dusk-600 px-4 py-2 text-sm text-dusk-200 transition hover:border-dusk-400 hover:text-dusk-100 disabled:opacity-40"
        >
          Clear
        </button>
      </div>
    </div>
  );
}
