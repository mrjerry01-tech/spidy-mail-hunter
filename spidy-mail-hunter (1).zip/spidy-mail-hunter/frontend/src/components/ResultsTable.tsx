import { useState } from "react";
import type { ResultFilter, ScanResult } from "../types";
import { StatusBadge } from "./StatusBadge";

interface Props {
  results: ScanResult[];
  filter: ResultFilter;
  onFilterChange: (f: ResultFilter) => void;
  search: string;
  onSearchChange: (s: string) => void;
}

function hostnameOf(url: string): string {
  try {
    return new URL(url.match(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//) ? url : `https://${url}`).hostname;
  } catch {
    return url;
  }
}

async function copyText(text: string) {
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    /* clipboard may be unavailable in insecure contexts; fail silently */
  }
}

export function ResultsTable({ results, filter, onFilterChange, search, onSearchChange }: Props) {
  const filtered = results.filter((r) => {
    if (filter !== "all" && r.status !== filter) return false;
    if (!search.trim()) return true;
    const needle = search.toLowerCase();
    return (
      r.url.toLowerCase().includes(needle) ||
      r.emails.some((e) => e.email.toLowerCase().includes(needle))
    );
  });

  return (
    <div className="border border-dusk-700 bg-dusk-900 rounded-sm">
      <div className="flex flex-wrap items-center gap-3 border-b border-dusk-700 px-4 py-3">
        <div className="flex gap-1">
          {(["all", "email_found", "no_email_found", "broken_link"] as ResultFilter[]).map((f) => (
            <button
              key={f}
              onClick={() => onFilterChange(f)}
              className={`rounded-sm px-2.5 py-1 font-mono text-xs transition ${
                filter === f ? "bg-thread text-dusk-950" : "text-dusk-300 hover:bg-dusk-800"
              }`}
            >
              {f === "all" ? "All" : f === "email_found" ? "Email Found" : f === "no_email_found" ? "No Email" : "Broken"}
            </button>
          ))}
        </div>
        <input
          value={search}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="Search URL or email…"
          className="ml-auto min-w-[180px] flex-1 rounded-sm border border-dusk-700 bg-dusk-950 px-3 py-1.5 font-mono text-xs text-dusk-100 placeholder:text-dusk-600 outline-none focus:border-thread sm:flex-none"
        />
      </div>

      {/* Desktop table */}
      <div className="hidden overflow-x-auto sm:block">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-dusk-700 font-mono text-xs uppercase tracking-wide text-dusk-400">
              <th className="w-12 px-4 py-2 font-medium">#</th>
              <th className="px-4 py-2 font-medium">Source URL</th>
              <th className="px-4 py-2 font-medium">Status</th>
              <th className="px-4 py-2 font-medium">Emails</th>
              <th className="px-4 py-2 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((r) => (
              <Row key={`${r.inputIndex}-${r.url}`} result={r} />
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile cards */}
      <div className="divide-y divide-dusk-700 sm:hidden">
        {filtered.map((r) => (
          <MobileCard key={`${r.inputIndex}-${r.url}`} result={r} />
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="px-4 py-10 text-center font-mono text-sm text-dusk-500">No results match this filter yet.</div>
      )}
    </div>
  );
}

function Row({ result }: { result: ScanResult }) {
  const [open, setOpen] = useState(false);
  return (
    <>
      <tr className="border-b border-dusk-800 align-top">
        <td className="px-4 py-3 font-mono text-dusk-400">{result.inputIndex + 1}</td>
        <td className="max-w-xs px-4 py-3">
          <div className="truncate font-mono text-dusk-100" title={result.url}>
            {hostnameOf(result.url)}
          </div>
          <div className="truncate text-xs text-dusk-500" title={result.url}>
            {result.url}
          </div>
        </td>
        <td className="px-4 py-3">
          <StatusBadge status={result.status} />
        </td>
        <td className="px-4 py-3">
          {result.emails.length === 0 ? (
            <span className="text-dusk-500">—</span>
          ) : (
            <ul className="space-y-1 font-mono text-dusk-100">
              {result.emails.map((e) => (
                <li key={e.email} className="flex items-center gap-2">
                  {e.email}
                  <button onClick={() => copyText(e.email)} className="text-xs text-dusk-500 hover:text-thread" title="Copy email">
                    copy
                  </button>
                </li>
              ))}
            </ul>
          )}
        </td>
        <td className="px-4 py-3">
          <button onClick={() => setOpen((o) => !o)} className="font-mono text-xs text-thread hover:underline">
            {open ? "Hide" : result.status === "broken_link" ? "Details" : "View"}
          </button>
        </td>
      </tr>
      {open && (
        <tr className="border-b border-dusk-800 bg-dusk-950/60">
          <td colSpan={5} className="px-4 py-3">
            <DetailPanel result={result} />
          </td>
        </tr>
      )}
    </>
  );
}

function MobileCard({ result }: { result: ScanResult }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="px-4 py-3">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="truncate font-mono text-sm text-dusk-100">{hostnameOf(result.url)}</div>
          <div className="truncate text-xs text-dusk-500">{result.url}</div>
        </div>
        <span className="font-mono text-xs text-dusk-500">#{result.inputIndex + 1}</span>
      </div>
      <div className="mt-2">
        <StatusBadge status={result.status} />
      </div>
      {result.emails.length > 0 && (
        <ul className="mt-2 space-y-1 font-mono text-sm text-dusk-100">
          {result.emails.map((e) => (
            <li key={e.email} className="flex items-center justify-between gap-2">
              <span className="truncate">{e.email}</span>
              <button onClick={() => copyText(e.email)} className="shrink-0 text-xs text-dusk-500 hover:text-thread">
                copy
              </button>
            </li>
          ))}
        </ul>
      )}
      <button onClick={() => setOpen((o) => !o)} className="mt-2 font-mono text-xs text-thread hover:underline">
        {open ? "Hide details" : "View details"}
      </button>
      {open && <div className="mt-2">
        <DetailPanel result={result} />
      </div>}
    </div>
  );
}

function DetailPanel({ result }: { result: ScanResult }) {
  return (
    <dl className="grid grid-cols-2 gap-x-4 gap-y-1 font-mono text-xs text-dusk-300 sm:grid-cols-4">
      <dt className="text-dusk-500">HTTP status</dt>
      <dd>{result.httpStatus ?? "—"}</dd>
      <dt className="text-dusk-500">Rendered with browser</dt>
      <dd>{result.usedBrowserRender ? "Yes" : "No"}</dd>
      <dt className="text-dusk-500">Error</dt>
      <dd className="col-span-3 sm:col-span-1">{result.error ?? "—"}</dd>
      {result.emails.length > 0 && (
        <>
          <dt className="col-span-2 mt-1 text-dusk-500 sm:col-span-4">Email sources</dt>
          {result.emails.map((e) => (
            <dd key={e.email} className="col-span-2 sm:col-span-4">
              {e.email} — <span className="text-dusk-500">{e.source.replace(/_/g, " ")}</span>
            </dd>
          ))}
        </>
      )}
    </dl>
  );
}
