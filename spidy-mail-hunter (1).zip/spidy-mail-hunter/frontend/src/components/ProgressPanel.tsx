import type { BatchProgress } from "../types";

interface Props {
  progress: BatchProgress;
  isRunning: boolean;
  isPaused: boolean;
  onPause: () => void;
  onResume: () => void;
  onStop: () => void;
}

export function ProgressPanel({ progress, isRunning, isPaused, onPause, onResume, onStop }: Props) {
  const pct = progress.total === 0 ? 0 : Math.round((progress.completed / progress.total) * 100);
  const remaining = progress.total - progress.completed;

  return (
    <div className="border border-dusk-700 bg-dusk-900 rounded-sm p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className={`h-2 w-2 rounded-full ${isRunning && !isPaused ? "bg-hunt animate-pulse" : "bg-dusk-600"}`} />
          <span className="font-display text-sm font-semibold text-dusk-100">
            {isPaused ? "Paused" : isRunning ? "Hunting emails…" : "Idle"}
          </span>
        </div>
        <div className="flex gap-2">
          {isRunning && !isPaused && (
            <button onClick={onPause} className="rounded-sm border border-dusk-600 px-3 py-1.5 text-xs text-dusk-200 hover:border-dusk-400">
              Pause
            </button>
          )}
          {isPaused && (
            <button onClick={onResume} className="rounded-sm border border-thread px-3 py-1.5 text-xs text-thread hover:bg-thread/10">
              Resume
            </button>
          )}
          {(isRunning || isPaused) && (
            <button onClick={onStop} className="rounded-sm border border-broken px-3 py-1.5 text-xs text-broken hover:bg-broken/10">
              Stop
            </button>
          )}
        </div>
      </div>

      <div className="mt-3">
        <div className="h-2 w-full overflow-hidden rounded-full bg-dusk-800">
          <div className="h-full rounded-full bg-thread transition-[width] duration-300" style={{ width: `${pct}%` }} />
        </div>
        <div className="mt-1.5 flex justify-between font-mono text-xs text-dusk-400">
          <span>
            {progress.completed} / {progress.total} processed
          </span>
          <span>{pct}%</span>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat label="Remaining" value={remaining} color="text-dusk-200" />
        <Stat label="Emails found" value={progress.emailFound} color="text-catch" />
        <Stat label="No email" value={progress.noEmailFound} color="text-empty" />
        <Stat label="Broken links" value={progress.brokenLink} color="text-broken" />
      </div>
    </div>
  );
}

function Stat({ label, value, color }: { label: string; value: number; color: string }) {
  return (
    <div className="border-l-2 border-dusk-700 pl-3">
      <div className={`font-mono text-lg font-semibold ${color}`}>{value}</div>
      <div className="text-[11px] uppercase tracking-wide text-dusk-400">{label}</div>
    </div>
  );
}
