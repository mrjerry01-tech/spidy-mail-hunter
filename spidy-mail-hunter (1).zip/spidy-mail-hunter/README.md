# Spidy Mail Hunter

Hunt publicly available emails from any webpage. Paste one URL or a thousand — Spidy Mail Hunter fetches each page, searches visible text, `mailto:` links, buttons, HTML source, obfuscated formats (`name [at] domain.com`), and — when needed — JavaScript-rendered content, then reports **Email Found**, **No Email Found**, or **Link is Broken** for every URL, in the exact order you submitted them.

It only ever reports emails it actually found on a publicly accessible page. It never guesses or invents addresses, and it never bypasses logins, paywalls, CAPTCHAs, or other access controls.

## Project structure

```
spidy-mail-hunter/
├── backend/     Express + TypeScript API: fetching, extraction, SSRF protection, SSE streaming
└── frontend/    React + TypeScript + Tailwind SaaS-style dashboard
```

## How it works

```
Frontend  →  POST /api/hunt  →  Concurrency-limited queue  →  URL Fetcher (SSRF-checked)
                                                                     ↓
                                                              HTML Parser (Cheerio)
                                                                     ↓
                                                        Email Extraction Engine (6 layers)
                                                                     ↓
                                              emails found? ──no──▶ Headless browser render (Playwright)
                                                     │ yes                    ↓
                                                     │              re-run extraction on rendered DOM
                                                     ▼                        ↓
                                              Result Normalizer  ◀────────────┘
                                                     ↓
                                     Server-Sent Events, tagged with an immutable inputIndex
                                                     ↓
                                        Frontend renders rows sorted by inputIndex
```

Every URL is assigned an `inputIndex` the moment it's submitted. Results stream back over SSE as each page finishes — possibly out of order — but the UI always renders rows sorted by `inputIndex`, so the table matches what you pasted in, top to bottom, including duplicate URLs.

## Getting started

Requires Node.js 18.17+.

### 1. Backend

```bash
cd backend
cp .env.example .env
npm install
npx playwright install chromium   # only needed the first time, for JS-rendered pages
npm run dev                       # starts the API on http://localhost:8787
```

### 2. Frontend

In a second terminal:

```bash
cd frontend
cp .env.example .env
npm install
npm run dev                       # starts the UI on http://localhost:5173
```

Open http://localhost:5173, paste some URLs, and click **Start Hunting**.

### Production build

```bash
# Backend
cd backend && npm run build && npm start

# Frontend
cd frontend && npm run build       # outputs static files to frontend/dist
```

Serve `frontend/dist` with any static host (Nginx, Vercel, Netlify, etc.) and point `VITE_API_BASE_URL` at your deployed backend before building.

### Tests

```bash
cd backend && npm test
cd frontend && npm test
```

Backend tests cover the email extraction engine (visible text, mailto, buttons, HTML/attributes, obfuscation, deduplication), SSRF protection, URL validation, and the batch orchestrator's ordering guarantee (including out-of-order completion and one failing URL not stopping the batch).

## Configuration (backend `.env`)

| Variable | Default | Purpose |
|---|---|---|
| `PORT` | `8787` | API port |
| `CORS_ORIGIN` | `http://localhost:5173` | Allowed frontend origin(s), comma-separated |
| `CONCURRENCY` | `5` | Max URLs fetched at once across the whole batch |
| `REQUEST_TIMEOUT_MS` | `10000` | Per-request timeout |
| `MAX_REDIRECTS` | `5` | Redirect hops followed (each one re-validated for SSRF) |
| `RETRY_COUNT` | `1` | Retries on transient network errors |
| `MAX_HTML_BYTES` | `3000000` | Cap on HTML downloaded per page |
| `ENABLE_BROWSER_RENDERING` | `true` | Fall back to Playwright when static HTML has no emails |
| `RENDER_TIMEOUT_MS` | `15000` | Timeout for headless-browser rendering |
| `MAX_CONCURRENT_BROWSER_PAGES` | `2` | Browser pages open at once (rendering is expensive) |
| `PER_HOST_RPS` | `1` | Requests per second to any single target host |

## Security notes

- **SSRF protection**: every URL — and every redirect hop it produces — is validated against loopback, private IPv4/IPv6 ranges, link-local addresses, and cloud metadata endpoints (`169.254.169.254`, etc.) before a request is made. DNS results are checked too, to guard against DNS-rebinding.
- **No credential/auth bypass**: the tool fetches pages exactly as an anonymous public visitor would. It does not attempt logins, solve CAPTCHAs, or evade bot/access-control mechanisms.
- **Responsible crawling**: a per-host rate limiter and global concurrency cap prevent hammering any single target site, and requests identify themselves with a descriptive `User-Agent`.
- **No guessing**: the extraction engine only reports emails it actually finds in publicly delivered page content (text, markup, attributes, or rendered DOM). It never fabricates likely addresses like `info@domain.com`.

## API

`POST /api/hunt`

```json
{ "urls": ["https://example.com", "https://example.org"] }
```

Response: `text/event-stream` (SSE). Each event is a JSON payload on a `data:` line:

```json
{"type":"result","result":{"inputIndex":0,"url":"https://example.com","status":"email_found","emails":[{"email":"info@example.com","source":"mailto"}], "...": "..."}}
{"type":"progress","progress":{"total":2,"completed":1,"emailFound":1,"noEmailFound":0,"brokenLink":0}}
{"type":"done","progress":{"total":2,"completed":2,"emailFound":1,"noEmailFound":1,"brokenLink":0}}
```

`POST /api/hunt/:batchId/cancel` — stops a running batch early (the `X-Batch-Id` response header on the initial `/api/hunt` call carries the ID).
