import type { Browser } from "playwright";
import { config } from "./config";

let browserPromise: Promise<Browser> | null = null;
let activePages = 0;
const waitQueue: Array<() => void> = [];

async function getBrowser(): Promise<Browser> {
  if (!browserPromise) {
    const { chromium } = await import("playwright");
    browserPromise = chromium.launch({ headless: true, args: ["--no-sandbox"] });
  }
  return browserPromise;
}

async function acquireSlot(): Promise<void> {
  if (activePages < config.maxConcurrentBrowserPages) {
    activePages++;
    return;
  }
  await new Promise<void>((resolve) => waitQueue.push(resolve));
  activePages++;
}

function releaseSlot(): void {
  activePages--;
  const next = waitQueue.shift();
  if (next) next();
}

/**
 * Renders a page with a real browser and returns the fully hydrated DOM HTML.
 * Only called as a fallback when static-HTML extraction finds nothing, since
 * launching a browser per page is far more expensive than a plain HTTP fetch.
 *
 * The same SSRF-validated URL that was already fetched safely is passed in;
 * navigation is restricted to that single URL (no following arbitrary links).
 */
export async function renderPageHtml(url: string): Promise<{ html: string | null; error: string | null }> {
  if (!config.enableBrowserRendering) return { html: null, error: "Browser rendering disabled" };

  await acquireSlot();
  let page: import("playwright").Page | null = null;
  try {
    const browser = await getBrowser();
    const context = await browser.newContext({ userAgent: config.userAgent, javaScriptEnabled: true });
    page = await context.newPage();

    // Block obviously unsafe navigations (e.g. a redirect chain the page triggers via JS).
    await page.route("**/*", async (route) => {
      const reqUrl = route.request().url();
      try {
        const parsed = new URL(reqUrl);
        if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
          return route.abort();
        }
      } catch {
        return route.abort();
      }
      return route.continue();
    });

    await page.goto(url, { waitUntil: "networkidle", timeout: config.renderTimeoutMs }).catch(async () => {
      // networkidle can time out on pages with persistent polling; fall back to a
      // shorter "domcontentloaded" wait so we still capture whatever rendered.
      await page.goto(url, { waitUntil: "domcontentloaded", timeout: config.renderTimeoutMs });
    });

    const html = await page.content();
    await context.close();
    return { html, error: null };
  } catch (err: any) {
    return { html: null, error: err?.message || "Rendering failed" };
  } finally {
    if (page) await page.close().catch(() => {});
    releaseSlot();
  }
}

export async function closeBrowser(): Promise<void> {
  if (browserPromise) {
    const browser = await browserPromise;
    await browser.close();
    browserPromise = null;
  }
}
