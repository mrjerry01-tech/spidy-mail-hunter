import pLimit from "p-limit";
import { config } from "./config";
import { scanSingleUrl } from "./scanner";
import type { BatchProgress, ScanResult } from "./types";

export interface BatchRunOptions {
  onResult: (result: ScanResult) => void;
  onProgress: (progress: BatchProgress) => void;
  isCancelled: () => boolean;
}

/**
 * Runs the full batch with a bounded concurrency pool while preserving the
 * caller's original ordering guarantee: every result carries its immutable
 * `inputIndex`, computed once up front from the raw input array, regardless
 * of which request happens to resolve first.
 */
export async function runBatch(urls: string[], options: BatchRunOptions): Promise<ScanResult[]> {
  const limit = pLimit(config.concurrency);
  const results: ScanResult[] = new Array(urls.length);

  const progress: BatchProgress = {
    total: urls.length,
    completed: 0,
    emailFound: 0,
    noEmailFound: 0,
    brokenLink: 0,
  };

  const tasks = urls.map((url, inputIndex) =>
    limit(async () => {
      if (options.isCancelled()) return;
      const result = await scanSingleUrl(inputIndex, url);
      results[inputIndex] = result; // written at its fixed position, independent of completion order
      progress.completed++;
      if (result.status === "email_found") progress.emailFound++;
      else if (result.status === "no_email_found") progress.noEmailFound++;
      else if (result.status === "broken_link") progress.brokenLink++;

      options.onResult(result);
      options.onProgress({ ...progress });
    })
  );

  await Promise.all(tasks);
  return results;
}
