import express from "express";
import cors from "cors";
import { config } from "./config";
import { huntHandler, cancelHandler } from "./routes/hunt";
import { closeBrowser } from "./renderer";

const app = express();

app.use(
  cors({
    origin: config.corsOrigin.split(",").map((s) => s.trim()),
  })
);
app.use(express.json({ limit: "1mb" }));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, concurrency: config.concurrency });
});

app.post("/api/hunt", huntHandler);
app.post("/api/hunt/:batchId/cancel", cancelHandler);

app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  // Generic error handler: never leak internal stack traces / network details to the client.
  // eslint-disable-next-line no-console
  console.error(err);
  res.status(500).json({ error: "Internal server error" });
});

const server = app.listen(config.port, () => {
  // eslint-disable-next-line no-console
  console.log(`Spidy Mail Hunter API listening on http://localhost:${config.port}`);
});

async function shutdown() {
  await closeBrowser();
  server.close(() => process.exit(0));
}

process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
