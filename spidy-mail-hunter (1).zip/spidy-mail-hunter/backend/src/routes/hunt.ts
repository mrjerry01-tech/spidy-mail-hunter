import type { Request, Response } from "express";
import { v4 as uuid } from "uuid";
import { config } from "../config";
import { runBatch } from "../batch";
import type { HuntRequestBody, SseEvent } from "../types";

// Tracks batches so a client can request cancellation mid-stream.
const activeBatches = new Map<string, { cancelled: boolean }>();

function sanitizeUrls(input: unknown): string[] {
  if (!Array.isArray(input)) return [];
  return input
    .filter((item): item is string => typeof item === "string")
    .slice(0, config.maxUrlsPerRequest);
}

function sendEvent(res: Response, event: SseEvent) {
  res.write(`data: ${JSON.stringify(event)}\n\n`);
}

/**
 * POST /api/hunt
 * Streams results via Server-Sent Events as each URL finishes, while the
 * client-side `inputIndex` on every result lets the frontend render rows
 * back into their original submitted order regardless of arrival order.
 */
export async function huntHandler(req: Request, res: Response) {
  const body = req.body as HuntRequestBody;
  const urls = sanitizeUrls(body?.urls);

  if (urls.length === 0) {
    res.status(400).json({ error: "Provide a non-empty 'urls' array." });
    return;
  }

  const batchId = uuid();
  const batchState = { cancelled: false };
  activeBatches.set(batchId, batchState);

  res.writeHead(200, {
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache",
    Connection: "keep-alive",
    "X-Batch-Id": batchId,
    "Access-Control-Expose-Headers": "X-Batch-Id",
  });
  res.write(`: batch-id ${batchId}\n\n`);

  req.on("close", () => {
    batchState.cancelled = true;
  });

  let lastProgress = { total: urls.length, completed: 0, emailFound: 0, noEmailFound: 0, brokenLink: 0 };

  try {
    await runBatch(urls, {
      onResult: (result) => sendEvent(res, { type: "result", result }),
      onProgress: (progress) => {
        lastProgress = progress;
        sendEvent(res, { type: "progress", progress });
      },
      isCancelled: () => batchState.cancelled,
    });
    sendEvent(res, { type: "done", progress: lastProgress });
  } catch (err: any) {
    sendEvent(res, { type: "error", message: err?.message || "Batch failed" });
  } finally {
    activeBatches.delete(batchId);
    res.end();
  }
}

export function cancelHandler(req: Request, res: Response) {
  const { batchId } = req.params;
  const batch = activeBatches.get(batchId);
  if (!batch) {
    res.status(404).json({ error: "Batch not found (it may have already finished)." });
    return;
  }
  batch.cancelled = true;
  res.json({ cancelled: true });
}
