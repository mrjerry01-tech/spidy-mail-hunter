import { config } from "./config";

/**
 * A tiny per-host rate limiter so a bulk batch that happens to contain many
 * URLs on the same domain doesn't hammer that target site. Independent of the
 * global concurrency limit, which caps total in-flight requests across all hosts.
 */
const lastRequestAtByHost = new Map<string, number>();

export async function waitForHostSlot(hostname: string): Promise<void> {
  const minGapMs = 1000 / Math.max(config.perHostRps, 0.01);
  const last = lastRequestAtByHost.get(hostname) ?? 0;
  const now = Date.now();
  const elapsed = now - last;
  if (elapsed < minGapMs) {
    await new Promise((resolve) => setTimeout(resolve, minGapMs - elapsed));
  }
  lastRequestAtByHost.set(hostname, Date.now());
}
