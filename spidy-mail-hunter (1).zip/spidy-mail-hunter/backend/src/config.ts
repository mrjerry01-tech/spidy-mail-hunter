import "dotenv/config";

function num(name: string, fallback: number): number {
  const raw = process.env[name];
  if (!raw) return fallback;
  const parsed = Number(raw);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function bool(name: string, fallback: boolean): boolean {
  const raw = process.env[name];
  if (raw === undefined) return fallback;
  return raw.toLowerCase() === "true" || raw === "1";
}

export const config = {
  port: num("PORT", 8787),
  corsOrigin: process.env.CORS_ORIGIN || "http://localhost:5173",
  concurrency: num("CONCURRENCY", 5),
  requestTimeoutMs: num("REQUEST_TIMEOUT_MS", 10000),
  maxRedirects: num("MAX_REDIRECTS", 5),
  retryCount: num("RETRY_COUNT", 1),
  retryDelayMs: num("RETRY_DELAY_MS", 500),
  maxHtmlBytes: num("MAX_HTML_BYTES", 3_000_000),
  userAgent: process.env.USER_AGENT || "SpidyMailHunter/1.0 (+public-email-discovery-bot)",
  enableBrowserRendering: bool("ENABLE_BROWSER_RENDERING", true),
  renderTimeoutMs: num("RENDER_TIMEOUT_MS", 15000),
  maxConcurrentBrowserPages: num("MAX_CONCURRENT_BROWSER_PAGES", 2),
  perHostRps: num("PER_HOST_RPS", 1),
  maxUrlsPerRequest: num("MAX_URLS_PER_REQUEST", 500),
};
