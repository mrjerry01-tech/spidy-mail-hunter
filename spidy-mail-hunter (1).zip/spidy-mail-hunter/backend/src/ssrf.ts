import dns from "node:dns";
import { isIP } from "node:net";

const dnsLookup = dns.promises.lookup;

/**
 * SSRF protection.
 *
 * The scanner accepts arbitrary user-supplied URLs, so every hostname it resolves
 * (the original URL AND every redirect hop) must be checked against private /
 * reserved / metadata address ranges before a request is made.
 */

const BLOCKED_HOSTNAMES = new Set([
  "localhost",
  "localhost.localdomain",
  "ip6-localhost",
  "ip6-loopback",
  "metadata.google.internal",
]);

// Cloud metadata endpoints - always blocked regardless of DNS resolution.
const BLOCKED_LITERAL_IPS = new Set([
  "169.254.169.254", // AWS / GCP / Azure metadata
  "169.254.170.2", // AWS ECS task metadata
  "fd00:ec2::254", // AWS IPv6 metadata
]);

interface CidrRange {
  base: bigint;
  bits: number;
  family: 4 | 6;
}

function ipv4ToBigInt(ip: string): bigint {
  return ip
    .split(".")
    .reduce((acc, octet) => (acc << 8n) + BigInt(parseInt(octet, 10)), 0n);
}

function ipv6ToBigInt(ip: string): bigint {
  // Expand :: shorthand
  const [head, tail] = ip.includes("::") ? ip.split("::") : [ip, ""];
  const headParts = head ? head.split(":") : [];
  const tailParts = tail ? tail.split(":") : [];
  const missing = 8 - headParts.length - tailParts.length;
  const full = [...headParts, ...Array(Math.max(missing, 0)).fill("0"), ...tailParts];
  return full.reduce((acc, part) => (acc << 16n) + BigInt(parseInt(part || "0", 16)), 0n);
}

function parseCidr(cidr: string, family: 4 | 6): CidrRange {
  const [addr, bitsStr] = cidr.split("/");
  const bits = parseInt(bitsStr, 10);
  const base = family === 4 ? ipv4ToBigInt(addr) : ipv6ToBigInt(addr);
  return { base, bits, family };
}

function inRange(ip: string, family: 4 | 6, range: CidrRange): boolean {
  if (range.family !== family) return false;
  const value = family === 4 ? ipv4ToBigInt(ip) : ipv6ToBigInt(ip);
  const totalBits = family === 4 ? 32 : 128;
  const shift = BigInt(totalBits - range.bits);
  return value >> shift === range.base >> shift;
}

const BLOCKED_IPV4_RANGES = [
  "0.0.0.0/8",
  "10.0.0.0/8",
  "100.64.0.0/10", // CGNAT
  "127.0.0.0/8",
  "169.254.0.0/16", // link-local + metadata
  "172.16.0.0/12",
  "192.0.0.0/24",
  "192.0.2.0/24",
  "192.168.0.0/16",
  "198.18.0.0/15",
  "198.51.100.0/24",
  "203.0.113.0/24",
  "224.0.0.0/4", // multicast
  "240.0.0.0/4", // reserved
  "255.255.255.255/32",
].map((c) => parseCidr(c, 4));

const BLOCKED_IPV6_RANGES = [
  "::/128",
  "::1/128", // loopback
  "::ffff:0:0/96", // ipv4-mapped (checked separately too)
  "64:ff9b::/96",
  "100::/64",
  "2001:db8::/32", // documentation
  "fc00::/7", // unique local
  "fe80::/10", // link-local
  "ff00::/8", // multicast
].map((c) => parseCidr(c, 6));

export function isBlockedIp(ip: string): boolean {
  if (BLOCKED_LITERAL_IPS.has(ip)) return true;
  const family = isIP(ip);
  if (family === 4) {
    return BLOCKED_IPV4_RANGES.some((r) => inRange(ip, 4, r));
  }
  if (family === 6) {
    // Handle IPv4-mapped IPv6 addresses (::ffff:a.b.c.d) by checking the embedded IPv4.
    const mapped = ip.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/i);
    if (mapped) return isBlockedIp(mapped[1]);
    return BLOCKED_IPV6_RANGES.some((r) => inRange(ip, 6, r));
  }
  // Not a recognizable IP literal.
  return false;
}

export class SsrfBlockedError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "SsrfBlockedError";
  }
}

/**
 * Validates a URL string: scheme, hostname, and (after DNS resolution) the
 * resulting IP address(es). Throws SsrfBlockedError if the target is unsafe.
 * Returns the resolved IP that will be connected to, for logging/pinning.
 */
export async function assertUrlIsSafe(rawUrl: string): Promise<{ url: URL; resolvedIp: string }> {
  let url: URL;
  try {
    url = new URL(rawUrl);
  } catch {
    throw new SsrfBlockedError("Invalid URL");
  }

  if (url.protocol !== "http:" && url.protocol !== "https:") {
    throw new SsrfBlockedError(`Unsupported protocol: ${url.protocol}`);
  }

  const hostname = url.hostname.toLowerCase().replace(/\.$/, "");

  if (BLOCKED_HOSTNAMES.has(hostname)) {
    throw new SsrfBlockedError("Blocked hostname");
  }

  if (hostname.endsWith(".local") || hostname.endsWith(".internal") || hostname.endsWith(".localhost")) {
    throw new SsrfBlockedError("Blocked internal hostname suffix");
  }

  // If the hostname is itself a literal IP, check it directly.
  if (isIP(hostname)) {
    if (isBlockedIp(hostname)) throw new SsrfBlockedError("Blocked IP address");
    return { url, resolvedIp: hostname };
  }

  // Resolve DNS and check every returned address (defends against DNS rebinding
  // where a hostname round-robins between a public and a private IP).
  let addresses: dns.LookupAddress[];
  try {
    addresses = await dnsLookup(hostname, { all: true, verbatim: true });
  } catch {
    throw new SsrfBlockedError("DNS resolution failed");
  }

  if (addresses.length === 0) {
    throw new SsrfBlockedError("DNS resolution returned no addresses");
  }

  for (const { address } of addresses) {
    if (isBlockedIp(address)) {
      throw new SsrfBlockedError("Blocked IP address (DNS resolved to a restricted range)");
    }
  }

  return { url, resolvedIp: addresses[0].address };
}
