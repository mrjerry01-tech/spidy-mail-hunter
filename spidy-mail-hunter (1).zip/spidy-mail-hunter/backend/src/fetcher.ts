import { request as undiciRequest } from "undici";
import { config } from "./config";
import { assertUrlIsSafe, SsrfBlockedError } from "./ssrf";

export interface FetchOutcome {
  ok: boolean;
  finalUrl: string | null;
  httpStatus: number | null;
  html: string | null;
  contentType: string | null;
  error: string | null;
}

/**
 * Fetches a URL manually following redirects one hop at a time so that every
 * hop (including the very first request) can be independently validated
 * against the SSRF blocklist. `undici`/`fetch` following redirects internally
 * would bypass this check for the 2nd+ hop.
 */
export async function safeFetchHtml(startUrl: string): Promise<FetchOutcome> {
  let currentUrl = startUrl;
  let lastStatus: number | null = null;

  for (let hop = 0; hop <= config.maxRedirects; hop++) {
    let safe: { url: URL };
    try {
      safe = await assertUrlIsSafe(currentUrl);
    } catch (err) {
      const message = err instanceof SsrfBlockedError ? err.message : "URL validation failed";
      return { ok: false, finalUrl: currentUrl, httpStatus: lastStatus, html: null, contentType: null, error: message };
    }

    const attempt = await fetchOnce(safe.url.toString());

    if (attempt.kind === "error") {
      return { ok: false, finalUrl: currentUrl, httpStatus: null, html: null, contentType: null, error: attempt.error };
    }

    lastStatus = attempt.status;

    if (attempt.status >= 300 && attempt.status < 400 && attempt.location) {
      currentUrl = new URL(attempt.location, safe.url).toString();
      continue; // validate the redirect target on the next loop iteration
    }

    if (attempt.status >= 400) {
      return {
        ok: false,
        finalUrl: safe.url.toString(),
        httpStatus: attempt.status,
        html: null,
        contentType: attempt.contentType,
        error: `HTTP ${attempt.status}`,
      };
    }

    return {
      ok: true,
      finalUrl: safe.url.toString(),
      httpStatus: attempt.status,
      html: attempt.body,
      contentType: attempt.contentType,
      error: null,
    };
  }

  return { ok: false, finalUrl: currentUrl, httpStatus: lastStatus, html: null, contentType: null, error: "Too many redirects" };
}

type OnceResult =
  | { kind: "ok"; status: number; location: string | null; body: string; contentType: string | null }
  | { kind: "error"; error: string };

async function fetchOnce(url: string, attemptsLeft = config.retryCount + 1): Promise<OnceResult> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), config.requestTimeoutMs);

  try {
    const res = await undiciRequest(url, {
      method: "GET",
      maxRedirections: 0, // we handle redirects ourselves for SSRF validation
      signal: controller.signal,
      headers: {
        "user-agent": config.userAgent,
        accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      },
    });

    const contentType = (res.headers["content-type"] as string) || null;
    const location = (res.headers["location"] as string) || null;

    // Avoid downloading huge/binary bodies. Non-text content can't contain
    // page-visible emails in the way this tool cares about.
    if (contentType && !/text|html|xml|json/i.test(contentType)) {
      res.body.destroy();
      return { kind: "ok", status: res.statusCode, location, body: "", contentType };
    }

    const body = await readBodyCapped(res.body, config.maxHtmlBytes);
    return { kind: "ok", status: res.statusCode, location, body, contentType };
  } catch (err: any) {
    clearTimeout(timeout);
    if (attemptsLeft > 1) {
      await sleep(config.retryDelayMs);
      return fetchOnce(url, attemptsLeft - 1);
    }
    const message = controller.signal.aborted ? "Request timed out" : describeNetworkError(err);
    return { kind: "error", error: message };
  } finally {
    clearTimeout(timeout);
  }
}

async function readBodyCapped(body: AsyncIterable<Uint8Array>, capBytes: number): Promise<string> {
  const chunks: Buffer[] = [];
  let total = 0;
  for await (const chunk of body) {
    total += chunk.length;
    chunks.push(Buffer.from(chunk));
    if (total >= capBytes) break;
  }
  return Buffer.concat(chunks).toString("utf-8");
}

function describeNetworkError(err: any): string {
  const code = err?.code || err?.cause?.code;
  switch (code) {
    case "ENOTFOUND":
      return "DNS lookup failed";
    case "ECONNREFUSED":
      return "Connection refused";
    case "ECONNRESET":
      return "Connection reset";
    case "CERT_HAS_EXPIRED":
    case "UNABLE_TO_VERIFY_LEAF_SIGNATURE":
    case "DEPTH_ZERO_SELF_SIGNED_CERT":
      return "TLS/SSL certificate error";
    default:
      return err?.message || "Network request failed";
  }
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
