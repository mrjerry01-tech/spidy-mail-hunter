import * as cheerio from "cheerio";
import type { EmailSource, FoundEmail } from "./types";

// Standard, reasonably strict email pattern. Deliberately avoids matching
// across newlines/HTML tags to reduce false positives from mashed-together text.
const EMAIL_REGEX = /[a-zA-Z0-9][a-zA-Z0-9._%+-]{0,63}@[a-zA-Z0-9][a-zA-Z0-9.-]{0,253}\.[a-zA-Z]{2,24}/g;

// Filters out obvious non-emails that technically match the pattern, e.g.
// image filenames pulled from `src` attributes (logo@2x.png) or CSS/JS artifacts.
const DISALLOWED_DOMAIN_SUFFIXES = [".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp", ".css", ".js"];
const PLACEHOLDER_LOCAL_PARTS = new Set(["example", "test", "your", "youremail", "email", "user", "name", "someone", "sentry"]);
const PLACEHOLDER_DOMAINS = new Set(["example.com", "example.org", "example.net", "domain.com", "yourdomain.com", "sentry.io", "wixpress.com", "godaddy.com", "schema.org", "w3.org"]);

export function normalizeEmail(raw: string): string | null {
  let email = raw.trim();

  // Decode common URL-encoded characters that survive into text nodes.
  try {
    email = decodeURIComponent(email);
  } catch {
    /* ignore malformed encoding */
  }

  // Strip surrounding punctuation/quotes/brackets often picked up from HTML/JSON.
  email = email.replace(/^["'<(\[{]+|["'>)\]}.,;:!?]+$/g, "");

  const match = email.match(EMAIL_REGEX);
  if (!match) return null;
  email = match[0];

  const [localPartRaw, domainRaw] = email.split("@");
  if (!localPartRaw || !domainRaw) return null;

  const domain = domainRaw.toLowerCase();
  // Technically the local-part is case-sensitive per RFC 5321, but in practice
  // (and per this tool's own dedup requirement) "INFO@x.com" and "info@x.com"
  // are the same publicly-advertised address, so we normalize to lowercase.
  const localPart = localPartRaw.toLowerCase();

  if (DISALLOWED_DOMAIN_SUFFIXES.some((ext) => domain.endsWith(ext))) return null;
  if (PLACEHOLDER_DOMAINS.has(domain)) return null;
  if (PLACEHOLDER_LOCAL_PARTS.has(localPart.toLowerCase()) && domain.endsWith("example.com")) return null;
  if (!domain.includes(".")) return null;

  return `${localPart}@${domain}`;
}

function dedupeKey(email: string): string {
  const [local, domain] = email.split("@");
  return `${local}@${domain.toLowerCase()}`;
}

/**
 * Finds emails that have been obfuscated with common human-readable patterns:
 *   john [at] example.com        john (at) example.com
 *   john AT example DOT com      john [at] example [dot] com
 *   john at example dot com
 * Deliberately conservative to avoid false positives on ordinary prose.
 */
const OBFUSCATION_PATTERNS: RegExp[] = [
  /([a-zA-Z0-9][a-zA-Z0-9._%+-]{0,63})\s*[\[(]\s*at\s*[\])]\s*([a-zA-Z0-9.-]+)\s*[\[(]\s*dot\s*[\])]\s*([a-zA-Z]{2,24})/gi,
  /([a-zA-Z0-9][a-zA-Z0-9._%+-]{0,63})\s*[\[(]\s*at\s*[\])]\s*([a-zA-Z0-9.-]+\.[a-zA-Z]{2,24})/gi,
  /([a-zA-Z0-9][a-zA-Z0-9._%+-]{0,63})\s+at\s+([a-zA-Z0-9-]+)\s+dot\s+([a-zA-Z]{2,24})/gi,
];

export function extractObfuscatedEmails(text: string): string[] {
  const found: string[] = [];
  for (const pattern of OBFUSCATION_PATTERNS) {
    pattern.lastIndex = 0;
    let m: RegExpExecArray | null;
    while ((m = pattern.exec(text)) !== null) {
      const [, local, domainPart, tld] = m;
      const candidate = tld ? `${local}@${domainPart}.${tld}` : `${local}@${domainPart}`;
      found.push(candidate);
    }
  }
  return found;
}

export interface ExtractionInput {
  html: string;
  sourceLabelForDom?: EmailSource; // "html" for raw fetch, "rendered_dom" for post-JS
}

/**
 * Runs every detection layer (visible text, mailto, HTML source/attributes,
 * buttons, obfuscated text) over a single HTML document and returns
 * deduplicated results with their originating source.
 */
export function extractEmailsFromHtml({ html, sourceLabelForDom = "html" }: ExtractionInput): FoundEmail[] {
  const results: FoundEmail[] = [];
  const seen = new Set<string>();

  const push = (raw: string, source: EmailSource) => {
    const normalized = normalizeEmail(raw);
    if (!normalized) return;
    const key = dedupeKey(normalized);
    if (seen.has(key)) return;
    seen.add(key);
    results.push({ email: normalized, source });
  };

  let $: cheerio.CheerioAPI;
  try {
    $ = cheerio.load(html, { xmlMode: false });
  } catch {
    // If parsing fails entirely, still try plain-text regex over the raw string.
    for (const m of html.match(EMAIL_REGEX) || []) push(m, sourceLabelForDom);
    for (const m of extractObfuscatedEmails(html)) push(m, "obfuscated_text");
    return results;
  }

  // Layer 2 — mailto links (covers nav/header/footer/contact links & buttons wrapped in <a>).
  $('a[href^="mailto:" i]').each((_, el) => {
    const href = $(el).attr("href") || "";
    const afterScheme = href.replace(/^mailto:/i, "");
    const addressPart = afterScheme.split("?")[0];
    for (const candidate of addressPart.split(",")) {
      push(decodeURIComponent(candidate), "mailto");
    }
  });

  // Layer 4 — buttons / interactive elements with a visible email as their label.
  $("button, [role=button], a, .btn, input[type=button], input[type=submit]").each((_, el) => {
    const text = $(el).text();
    for (const m of text.match(EMAIL_REGEX) || []) push(m, "button");
    const value = $(el).attr("value");
    if (value) for (const m of value.match(EMAIL_REGEX) || []) push(m, "button");
  });

  // Layer 1 — visible text (body text as rendered, ignoring script/style content).
  $("script, style, noscript").remove();
  const bodyText = $("body").length ? $("body").text() : $.root().text();
  for (const m of bodyText.match(EMAIL_REGEX) || []) push(m, "visible_text");
  for (const m of extractObfuscatedEmails(bodyText)) push(m, "obfuscated_text");

  // Layer 3 — full HTML source: attributes, data-* attributes, embedded JSON/script data, metadata.
  // Re-parse the ORIGINAL html (before script/style removal) so <script type="application/ld+json">
  // and other embedded data blocks are still included.
  const $full = cheerio.load(html, { xmlMode: false });
  $full("*").each((_, el) => {
    const attribs = (el as any).attribs as Record<string, string> | undefined;
    if (!attribs) return;
    for (const [attrName, attrValue] of Object.entries(attribs)) {
      if (!attrValue || attrName === "href") continue; // href already covered by mailto layer
      for (const m of attrValue.match(EMAIL_REGEX) || []) {
        push(m, attrName.startsWith("data-") ? "embedded_data" : "html");
      }
    }
  });
  $full("script[type='application/ld+json'], script[type='application/json']").each((_, el) => {
    const content = $full(el).contents().text();
    for (const m of content.match(EMAIL_REGEX) || []) push(m, "embedded_data");
    for (const m of extractObfuscatedEmails(content)) push(m, "obfuscated_text");
  });
  // Raw HTML sweep catches anything left in comments, inline scripts, or malformed markup.
  for (const m of html.match(EMAIL_REGEX) || []) push(m, sourceLabelForDom);
  for (const m of extractObfuscatedEmails(html)) push(m, "obfuscated_text");

  return results;
}
