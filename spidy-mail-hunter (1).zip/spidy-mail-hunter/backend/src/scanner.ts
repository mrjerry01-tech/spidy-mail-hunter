import { safeFetchHtml } from "./fetcher";
import { extractEmailsFromHtml } from "./extractor";
import { renderPageHtml } from "./renderer";
import { waitForHostSlot } from "./hostRateLimiter";
import type { ScanResult } from "./types";

export function normalizeInputUrl(raw: string): string | null {
  let candidate = raw.trim();
  if (!candidate) return null;
  if (!/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(candidate)) {
    candidate = `https://${candidate}`;
  }
  try {
    const url = new URL(candidate);
    if (url.protocol !== "http:" && url.protocol !== "https:") return null;
    return url.toString();
  } catch {
    return null;
  }
}

/**
 * Runs the full detection pipeline for a single URL:
 *   fetch -> extract from static HTML -> (if empty) render with a headless
 *   browser -> extract from rendered DOM -> dedupe -> classify status.
 */
export async function scanSingleUrl(inputIndex: number, rawUrl: string): Promise<ScanResult> {
  const startedAt = Date.now();
  const base: ScanResult = {
    inputIndex,
    url: rawUrl,
    normalizedUrl: null,
    status: "processing",
    emails: [],
    httpStatus: null,
    error: null,
    usedBrowserRender: false,
    startedAt,
    finishedAt: null,
  };

  const normalized = normalizeInputUrl(rawUrl);
  if (!normalized) {
    return { ...base, status: "broken_link", error: "Invalid URL", finishedAt: Date.now() };
  }
  base.normalizedUrl = normalized;

  try {
    const hostname = new URL(normalized).hostname;
    await waitForHostSlot(hostname);
  } catch {
    /* already validated above; ignore */
  }

  const fetchResult = await safeFetchHtml(normalized);

  if (!fetchResult.ok) {
    return {
      ...base,
      status: "broken_link",
      httpStatus: fetchResult.httpStatus,
      error: fetchResult.error,
      finishedAt: Date.now(),
    };
  }

  let emails = extractEmailsFromHtml({ html: fetchResult.html || "", sourceLabelForDom: "html" });
  let usedBrowserRender = false;

  if (emails.length === 0) {
    const rendered = await renderPageHtml(fetchResult.finalUrl || normalized);
    if (rendered.html) {
      usedBrowserRender = true;
      const renderedEmails = extractEmailsFromHtml({ html: rendered.html, sourceLabelForDom: "rendered_dom" });
      if (renderedEmails.length > 0) emails = renderedEmails;
    }
  }

  return {
    ...base,
    status: emails.length > 0 ? "email_found" : "no_email_found",
    emails,
    httpStatus: fetchResult.httpStatus,
    usedBrowserRender,
    finishedAt: Date.now(),
  };
}
