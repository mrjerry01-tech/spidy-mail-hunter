import { describe, expect, it } from "vitest";
import { extractEmailsFromHtml, extractObfuscatedEmails, normalizeEmail } from "../src/extractor";

describe("normalizeEmail", () => {
  it("lowercases both local-part and domain for consistent deduplication", () => {
    expect(normalizeEmail("Hello@Example.COM")).toBe("hello@example.com");
  });

  it("trims whitespace and surrounding punctuation", () => {
    expect(normalizeEmail("  <hello@example.org>. ")).toBe("hello@example.org");
  });

  it("decodes URL-encoded values", () => {
    expect(normalizeEmail("hello%40example.org")).toBe("hello@example.org");
  });

  it("rejects non-email strings", () => {
    expect(normalizeEmail("not-an-email")).toBeNull();
  });

  it("rejects filenames that happen to contain @", () => {
    expect(normalizeEmail("logo@2x.png")).toBeNull();
  });
});

describe("extractObfuscatedEmails", () => {
  it("handles [at]/[dot] style", () => {
    expect(extractObfuscatedEmails("Reach john [at] example [dot] com anytime")).toContain("john@example.com");
  });

  it("handles (at) style with direct domain", () => {
    expect(extractObfuscatedEmails("contact: jane (at) example.com")).toContain("jane@example.com");
  });

  it("handles spelled out 'at'/'dot'", () => {
    expect(extractObfuscatedEmails("mail me at sam at example dot com")).toContain("sam@example.com");
  });

  it("does not falsely trigger on ordinary prose", () => {
    expect(extractObfuscatedEmails("Look at the cat sitting on the mat.")).toHaveLength(0);
  });
});

describe("extractEmailsFromHtml - visible text", () => {
  it("finds a plain visible email", () => {
    const html = `<html><body><p>Contact us at hello@example.com for help.</p></body></html>`;
    const emails = extractEmailsFromHtml({ html });
    expect(emails.map((e) => e.email)).toContain("hello@example.com");
    expect(emails.find((e) => e.email === "hello@example.com")?.source).toBe("visible_text");
  });
});

describe("extractEmailsFromHtml - mailto links", () => {
  it("extracts from a mailto href", () => {
    const html = `<a href="mailto:hello@example.com">Email us</a>`;
    const emails = extractEmailsFromHtml({ html });
    expect(emails.map((e) => e.email)).toContain("hello@example.com");
    expect(emails.find((e) => e.email === "hello@example.com")?.source).toBe("mailto");
  });

  it("strips query params like ?subject=", () => {
    const html = `<a href="mailto:hello@example.com?subject=Contact%20Us">Email</a>`;
    const emails = extractEmailsFromHtml({ html });
    expect(emails.map((e) => e.email)).toEqual(["hello@example.com"]);
  });
});

describe("extractEmailsFromHtml - buttons", () => {
  it("finds an email used as button label", () => {
    const html = `<button>sales@example.com</button>`;
    const emails = extractEmailsFromHtml({ html });
    expect(emails.find((e) => e.email === "sales@example.com")?.source).toBe("button");
  });
});

describe("extractEmailsFromHtml - HTML source / attributes", () => {
  it("finds an email inside a data attribute", () => {
    const html = `<div data-contact="team@example.com"></div>`;
    const emails = extractEmailsFromHtml({ html });
    expect(emails.find((e) => e.email === "team@example.com")?.source).toBe("embedded_data");
  });

  it("finds an email inside embedded JSON-LD", () => {
    const html = `<script type="application/ld+json">{"email":"json@example.com"}</script>`;
    const emails = extractEmailsFromHtml({ html });
    expect(emails.map((e) => e.email)).toContain("json@example.com");
  });
});

describe("extractEmailsFromHtml - obfuscation", () => {
  it("normalizes obfuscated emails found in body text", () => {
    const html = `<body>Say hi: jane [at] example [dot] com</body>`;
    const emails = extractEmailsFromHtml({ html });
    expect(emails.find((e) => e.email === "jane@example.com")?.source).toBe("obfuscated_text");
  });
});

describe("extractEmailsFromHtml - deduplication", () => {
  it("dedupes case-insensitive duplicates across layers", () => {
    const html = `
      <a href="mailto:INFO@example.com">Email</a>
      <p>Or write to info@example.com directly.</p>
    `;
    const emails = extractEmailsFromHtml({ html });
    const matches = emails.filter((e) => e.email.toLowerCase() === "info@example.com");
    expect(matches).toHaveLength(1);
  });
});

describe("extractEmailsFromHtml - never guesses", () => {
  it("returns nothing for a page with no email-like content", () => {
    const html = `<html><body><h1>Welcome</h1><p>We build great things.</p></body></html>`;
    expect(extractEmailsFromHtml({ html })).toHaveLength(0);
  });
});
