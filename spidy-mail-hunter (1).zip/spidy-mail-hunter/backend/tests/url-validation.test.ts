import { describe, expect, it } from "vitest";
import { normalizeInputUrl } from "../src/scanner";

describe("normalizeInputUrl", () => {
  it("adds https:// when no scheme is present", () => {
    expect(normalizeInputUrl("example.com")).toBe("https://example.com/");
  });

  it("preserves an explicit http:// scheme", () => {
    expect(normalizeInputUrl("http://example.com")).toBe("http://example.com/");
  });

  it("rejects empty strings", () => {
    expect(normalizeInputUrl("   ")).toBeNull();
  });

  it("rejects non-http(s) schemes", () => {
    expect(normalizeInputUrl("ftp://example.com")).toBeNull();
  });

  it("rejects unparsable input", () => {
    expect(normalizeInputUrl("http://")).toBeNull();
  });
});
