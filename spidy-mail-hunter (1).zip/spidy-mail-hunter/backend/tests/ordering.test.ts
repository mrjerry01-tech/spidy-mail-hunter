import { describe, expect, it, vi } from "vitest";

// Mock the scanner so the batch test is fast, deterministic, and network-free:
// URLs "resolve" in a deliberately scrambled order (C, A, E, B, D) to prove
// that final results still come back sorted by inputIndex.
vi.mock("../src/scanner", () => {
  return {
    scanSingleUrl: vi.fn(async (inputIndex: number, url: string) => {
      const delays = [30, 10, 5, 25, 1]; // A,B,C,D,E finish out of order
      await new Promise((resolve) => setTimeout(resolve, delays[inputIndex] ?? 10));
      return {
        inputIndex,
        url,
        normalizedUrl: url,
        status: "no_email_found" as const,
        emails: [],
        httpStatus: 200,
        error: null,
        usedBrowserRender: false,
        startedAt: Date.now(),
        finishedAt: Date.now(),
      };
    }),
  };
});

import { runBatch } from "../src/batch";

describe("runBatch ordering guarantee", () => {
  it("returns results sorted by inputIndex regardless of completion order", async () => {
    const urls = ["https://a.com", "https://b.com", "https://c.com", "https://d.com", "https://e.com"];
    const completionOrder: number[] = [];

    const results = await runBatch(urls, {
      onResult: (r) => completionOrder.push(r.inputIndex),
      onProgress: () => {},
      isCancelled: () => false,
    });

    // Sanity check: our mock did in fact complete out of order.
    expect(completionOrder).not.toEqual([0, 1, 2, 3, 4]);

    // But the final array is always index-aligned with the input.
    expect(results.map((r) => r.url)).toEqual(urls);
    results.forEach((r, i) => expect(r.inputIndex).toBe(i));
  });

  it("preserves duplicate URLs as separate, independently-positioned entries", async () => {
    const urls = ["https://x.com", "https://y.com", "https://x.com"];
    const results = await runBatch(urls, { onResult: () => {}, onProgress: () => {}, isCancelled: () => false });
    expect(results).toHaveLength(3);
    expect(results[0].url).toBe("https://x.com");
    expect(results[2].url).toBe("https://x.com");
    expect(results[0].inputIndex).toBe(0);
    expect(results[2].inputIndex).toBe(2);
  });

  it("one failing URL does not stop the rest of the batch", async () => {
    const { scanSingleUrl } = await import("../src/scanner");
    (scanSingleUrl as any).mockImplementationOnce(async (inputIndex: number, url: string) => ({
      inputIndex,
      url,
      normalizedUrl: url,
      status: "broken_link",
      emails: [],
      httpStatus: null,
      error: "Connection refused",
      usedBrowserRender: false,
      startedAt: Date.now(),
      finishedAt: Date.now(),
    }));

    const urls = ["https://broken.com", "https://ok.com"];
    const results = await runBatch(urls, { onResult: () => {}, onProgress: () => {}, isCancelled: () => false });
    expect(results[0].status).toBe("broken_link");
    expect(results[1].status).toBe("no_email_found");
  });
});
