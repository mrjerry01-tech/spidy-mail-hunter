import { describe, expect, it } from "vitest";
import { isBlockedIp, assertUrlIsSafe, SsrfBlockedError } from "../src/ssrf";

describe("isBlockedIp", () => {
  it("blocks loopback", () => {
    expect(isBlockedIp("127.0.0.1")).toBe(true);
    expect(isBlockedIp("::1")).toBe(true);
  });

  it("blocks private IPv4 ranges", () => {
    expect(isBlockedIp("10.1.2.3")).toBe(true);
    expect(isBlockedIp("172.16.0.5")).toBe(true);
    expect(isBlockedIp("192.168.1.1")).toBe(true);
  });

  it("blocks link-local and cloud metadata", () => {
    expect(isBlockedIp("169.254.169.254")).toBe(true);
    expect(isBlockedIp("169.254.1.1")).toBe(true);
  });

  it("blocks private IPv6 ranges", () => {
    expect(isBlockedIp("fe80::1")).toBe(true);
    expect(isBlockedIp("fc00::1")).toBe(true);
  });

  it("blocks IPv4-mapped IPv6 addresses to private ranges", () => {
    expect(isBlockedIp("::ffff:10.0.0.1")).toBe(true);
  });

  it("allows ordinary public IPv4 addresses", () => {
    expect(isBlockedIp("8.8.8.8")).toBe(false);
    expect(isBlockedIp("93.184.216.34")).toBe(false);
  });
});

describe("assertUrlIsSafe", () => {
  it("rejects non-http(s) protocols", async () => {
    await expect(assertUrlIsSafe("file:///etc/passwd")).rejects.toBeInstanceOf(SsrfBlockedError);
  });

  it("rejects localhost", async () => {
    await expect(assertUrlIsSafe("http://localhost:8080")).rejects.toBeInstanceOf(SsrfBlockedError);
  });

  it("rejects literal loopback IP", async () => {
    await expect(assertUrlIsSafe("http://127.0.0.1")).rejects.toBeInstanceOf(SsrfBlockedError);
  });

  it("rejects literal private IP", async () => {
    await expect(assertUrlIsSafe("http://192.168.0.1")).rejects.toBeInstanceOf(SsrfBlockedError);
  });

  it("rejects cloud metadata IP", async () => {
    await expect(assertUrlIsSafe("http://169.254.169.254/latest/meta-data")).rejects.toBeInstanceOf(SsrfBlockedError);
  });

  it("rejects malformed URLs", async () => {
    await expect(assertUrlIsSafe("not a url")).rejects.toBeInstanceOf(SsrfBlockedError);
  });

  it("rejects internal hostname suffixes", async () => {
    await expect(assertUrlIsSafe("http://printer.local")).rejects.toBeInstanceOf(SsrfBlockedError);
  });
});
